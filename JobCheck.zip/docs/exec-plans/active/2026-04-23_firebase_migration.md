# 실행 계획: 노션 → 파이어베이스 데이터베이스 전환

## 1. 개요
현재 노션 API를 통해 관리 중인 '할일 체크리스트'의 데이터를 파이어베이스(Firestore)로 이전하고, 데이터베이스 엔진을 교체합니다.

## 2. 주요 작업 단계
### Phase 1: 환경 설정 (In Progress)
- [ ] 파이어베이스 관리자 도구(`firebase-tools`) 설치
- [ ] 파이어베이스 프로젝트 생성 및 초기화 (`firebase init`)
- [v] 웹 및 관리자용 SDK 설치 (`npm install firebase firebase-admin`)

### Phase 2: 아키텍처 재설계 (Layered Domain Architecture 준수)
- [ ] **Config**: 파이어베이스 설정값 추가 (`firebaseConfig`)
- [ ] **Types**: Firestore 문서 구조에 맞는 인터페이스 정의
- [ ] **Repo**: `NotionRepository`를 대체할 `FirestoreRepository` 구현
- [ ] **Service**: 파이어베이스 특화 로직 반영 및 서비스 업데이트

### Phase 3: 데이터 및 UI 마이그레이션
- [ ] (선택) 기존 노션 데이터를 파이어베이스로 이전하는 스크립트 작성
- [ ] UI 컴포넌트에서 파이어베이스 데이터 바인딩 확인

### Phase 4: 검증 및 완료
- [ ] 실시간 데이터 업데이트 테스트
- [ ] `docs/exec-plans/completed/`로 리포트 이동

## 3. 아키텍처 제약사항
- `src/lib/firebase/` 디렉토리에 파이어베이스 관련 설정을 모듈화하여 관리합니다.
- 의존성 규칙: `UI -> Runtime -> Service -> Repo -> Config -> Types` 순서를 엄격히 준수합니다.
