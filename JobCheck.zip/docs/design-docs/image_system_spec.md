# 이미지 처리 및 최적화 시스템 명세 (Image Processing System)

이 문서는 꿀송이농장 작업관리시스템의 이미지 처리 로직과 최적화 전략을 기록합니다. 향후 시스템 유지보수 및 성능 튜닝 시 이 가이드를 따릅니다.

## 1. 클라이언트 측 이미지 압축 (Client-side Compression)

사용자가 사진을 업로드할 때, 서버로 전송하기 전 브라우저에서 즉시 리사이징 및 압축을 수행하여 데이터 사용량을 최소화하고 업로드 속도를 높입니다.

- **관련 파일**: `src/utils/imageUtils.ts`
- **압축 로직**: Canvas API를 활용한 커스텀 압축 시스템
- **상세 파라미터**:
    - **최대 해상도 (MAX_SIZE)**: 가로 또는 세로 중 긴 쪽을 **800px**로 제한.
    - **출력 포맷**: `image/jpeg`
    - **압축 품질 (Quality)**: **0.7 (70%)**
- **기대 결과**: 평균 5MB~10MB의 원본 사진을 **약 100KB~150KB** 내외로 최적화.

## 2. 이미지 로딩 및 사용자 경험 (UX Strategy)

이미지가 노출될 때 사용자에게 신뢰감 있고 부드러운 경험을 제공하기 위한 전략입니다.

- **스마트 프리로딩 (Pre-fetching)**: 
    - `DailyView.tsx`에서 현재 날짜의 할일 목록(`viewTasks`)이 변경될 때, 포함된 모든 이미지 URL을 `new Image()` 객체를 통해 미리 로드합니다.
- **스켈레톤 UI (Skeleton UI)**:
    - 이미지가 실제로 화면에 렌더링되기 전까지 `animate-shimmer` 효과가 적용된 회색 박스를 노출합니다.
    - 로딩 중임을 시각적으로 정직하게 보여줌으로써 시스템의 안정성을 전달합니다.
- **부드러운 전환 (Fade-in)**:
    - 로딩 완료 시 `opacity` 전환 효과(`duration-500`)를 통해 사진이 부드럽게 나타나도록 합니다.

## 3. 호출 흐름 (Flow)

1. `DailyView.tsx` (`handleImageChange`) -> 파일 선택
2. `imageUtils.ts` (`compressImage`) -> **1280px / 0.7 품질**로 압축
3. `jobService.ts` (`uploadImages`) -> 최적화된 파일을 Firebase Storage에 업로드
4. `DailyView.tsx` (`ImageWithSkeleton`) -> 로딩 중 스켈레톤 노출 후 부드러운 출력

---
**마지막 업데이트**: 2026-04-26
**담당**: Antigravity (Harness Engineering System)
