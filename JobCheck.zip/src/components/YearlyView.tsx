import { useState } from "react";
import { format, startOfYear, eachMonthOfInterval, isSameMonth } from "date-fns";
import { ko } from "date-fns/locale";
import { CalendarRange, Target, CheckCircle2, Sprout, Clock, ChevronDown, ChevronUp } from "lucide-react";
import { Job } from "@/types";

export default function YearlyView({
  tasks,
}: {
  tasks: Job[];
}) {
  const [selectedMonth, setSelectedMonth] = useState<Date | null>(null);
  const currentYear = new Date().getFullYear();
  const yearStart = startOfYear(new Date());
  const months = eachMonthOfInterval({
    start: yearStart,
    end: new Date(currentYear, 11, 31),
  });

  const handleMonthClick = (month: Date) => {
    if (selectedMonth && isSameMonth(selectedMonth, month)) {
      setSelectedMonth(null);
    } else {
      setSelectedMonth(month);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-10">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div className="bg-green-500/10 p-2 rounded-xl text-green-600">
          <CalendarRange className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-[var(--foreground)]">{currentYear}년 농장 연간 계획</h2>
          <p className="text-sm text-gray-400">올 한 해의 농사 흐름을 한눈에 확인하세요.</p>
        </div>
      </div>

      {/* 12 Months Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 items-start">
        {months.map((month) => {
          const monthTasks = tasks.filter((t) => isSameMonth(new Date(t.date), month));
          const completedCount = monthTasks.filter((t) => t.is_done).length;
          const progress = monthTasks.length > 0 ? (completedCount / monthTasks.length) * 100 : 0;
          const isSelected = selectedMonth && isSameMonth(month, selectedMonth);

          // Sort tasks for full list view
          const sortedTasks = [...monthTasks].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

          return (
            <div 
              key={month.toISOString()} 
              onClick={() => handleMonthClick(month)}
              className={`bg-[var(--card-bg)] rounded-3xl border shadow-sm hover:shadow-xl transition-all duration-500 overflow-hidden group cursor-pointer relative flex flex-col ${
                isSelected ? "border-green-500 ring-4 ring-green-500/10 scale-[1.02] z-10" : "border-[var(--card-border)] hover:-translate-y-1"
              }`}
            >
              {/* Month Header */}
              <div className={`p-5 border-b transition-colors ${
                isSelected ? "bg-green-600 text-white border-green-700" : "border-[var(--card-border)] bg-gradient-to-br from-[var(--card-bg)] to-[var(--input-bg)]/30"
              }`}>
                <div className="flex justify-between items-center mb-1">
                  <span className={`text-2xl font-black ${isSelected ? "text-white" : "text-green-600"}`}>
                    {format(month, "M월")}
                  </span>
                  <div className={`${isSelected ? "bg-white/20" : "bg-[var(--input-bg)]"} px-2 py-1 rounded-lg border ${isSelected ? "border-white/30" : "border-[var(--card-border)]"} shadow-sm`}>
                    <span className={`text-xs font-bold ${isSelected ? "text-white" : "text-green-600"}`}>
                      {monthTasks.length}건
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className={`flex items-center gap-1.5 text-[10px] font-medium ${isSelected ? "text-white/70" : "text-gray-400"}`}>
                    <span className="uppercase tracking-wider">
                      {format(month, "MMMM", { locale: ko })}
                    </span>
                  </div>
                  {isSelected ? <ChevronUp className="w-4 h-4 text-white/50" /> : <ChevronDown className="w-4 h-4 text-gray-300" />}
                </div>
              </div>

              {/* Month Body */}
              <div className={`p-5 space-y-4 flex-1 flex flex-col ${isSelected ? "bg-[var(--card-bg)]" : ""}`}>
                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-[10px] font-bold">
                    <span className="text-gray-400">완료율</span>
                    <span className="text-green-600">{Math.round(progress)}%</span>
                  </div>
                  <div className={`h-1.5 w-full rounded-full overflow-hidden border ${isSelected ? "bg-green-500/10 border-green-500/20" : "bg-[var(--input-bg)] border-[var(--card-border)]"}`}>
                    <div 
                      className="h-full bg-green-500 rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(34,197,94,0.3)]"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Tasks Content */}
                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                    <Target className="w-3 h-3" />
                    <span>{isSelected ? "전체 일정" : "주요 활동"}</span>
                  </div>

                  {monthTasks.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-4 opacity-10">
                      <Sprout className="w-6 h-6 text-green-300" />
                    </div>
                  ) : isSelected ? (
                    /* Detailed Full List - Compact One Line */
                    <div className="space-y-1 max-h-[400px] overflow-y-auto pr-1 custom-scrollbar animate-in fade-in slide-in-from-top-2 duration-300">
                      {sortedTasks.map((task) => (
                        <div 
                          key={task.id} 
                          className={`flex items-center gap-2 py-1.5 px-2 rounded-lg transition-all duration-200 ${
                            task.is_done ? "opacity-50" : "hover:bg-green-500/5"
                          }`}
                        >
                          <span className="text-[10px] font-black text-green-600 shrink-0 min-w-[28px]">
                            {format(new Date(task.date), "d일")}
                          </span>
                          <span className="text-[10px] font-mono text-gray-400 shrink-0 min-w-[35px]">
                            {format(new Date(task.date), "HH:mm")}
                          </span>
                          <p className={`text-[11px] font-bold truncate flex-1 ${task.is_done ? "text-gray-400 line-through decoration-1" : "text-[var(--foreground)]"}`}>
                            {task.task}
                          </p>
                          {task.is_done && (
                            <div className="w-1.5 h-1.5 rounded-full bg-green-500/30 shrink-0" />
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    /* Simple Summary View */
                    <div className="space-y-1.5 min-h-[60px]">
                      {monthTasks.slice(0, 2).map((task) => (
                        <div key={task.id} className="flex items-center gap-2 group/task">
                          <div className={`w-1 h-1 rounded-full ${task.is_done ? "bg-gray-500/50" : "bg-green-500"}`} />
                          <span className={`text-xs truncate font-medium ${task.is_done ? "text-gray-500 line-through" : "text-[var(--foreground)]"}`}>
                            {task.task}
                          </span>
                        </div>
                      ))}
                      {monthTasks.length > 2 && (
                        <p className="text-[9px] text-gray-400 pl-3">외 {monthTasks.length - 2}개 일정 더 있음...</p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Footer Indicator */}
              {monthTasks.length > 0 && progress === 100 && (
                <div className="absolute top-2 right-2 scale-110">
                  <CheckCircle2 className="w-5 h-5 text-green-500 fill-[var(--card-bg)]" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Yearly Summary Legend */}
      <div className="bg-green-800 text-white rounded-3xl p-8 shadow-2xl shadow-green-900/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6 text-center md:text-left">
          <div>
            <h3 className="text-xl font-black mb-1">{currentYear}년 농사 성적표</h3>
            <p className="text-green-100/70 text-sm">성실한 대장님의 한 해가 기록되고 있습니다.</p>
          </div>
          <div className="flex gap-8">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black">{tasks.length}</span>
              <span className="text-[10px] uppercase font-bold text-green-200">총 일정</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black">{tasks.filter(t => t.is_done).length}</span>
              <span className="text-[10px] uppercase font-bold text-green-200">완료됨</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black">
                {Math.round((tasks.filter(t => t.is_done).length / (tasks.length || 1)) * 100)}%
              </span>
              <span className="text-[10px] uppercase font-bold text-green-200">평균 달성률</span>
            </div>
          </div>
        </div>
        {/* Background Decorative Sprout */}
        <Sprout className="absolute -right-10 -bottom-10 w-48 h-48 text-white/5 rotate-12" />
      </div>
    </div>
  );
}
